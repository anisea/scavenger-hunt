# Cipher Scavenger Hunt - Deployment & Solution Guide

This document contains instructions for deploying the 8-stage scavenger hunt and the solution keys required to track the player's progress.

## Deployment Instructions (GitHub Pages / Netlify)

### Option A: GitHub Pages
1. Create a new public repository on GitHub (e.g., `cipher-hunt`).
2. Upload all HTML files (`stage1.html` through `stage8.html`) and this `README.md` to the root of the repository.
3. Go to your repository settings -> **Pages**.
4. Set the Build and deployment source to **Deploy from a branch** (`main` or `master`, root folder `/`).
5. Your starting URL will be: `https://<your-username>.github.io/<repository-name>/stage1.html`

### Option B: Netlify
1. Log in to Netlify and drag and drop your project folder containing all the HTML files into the deployment drop zone.
2. Once deployed, you can rename your site or use the provided URL.
3. Your starting URL will be: `https://<your-site-name>.netlify.app/stage1.html`

---

## Master Route & Answer Key (Private Reference)

| Stage | Cipher Type | Ciphertext / Clue | Answer / Next URL |
| :--- | :--- | :--- | :--- |
| **Stage 1** | Caesar Cipher (Shift +3) | `FRUAQ KDW WKH QH[W SURJUDP LV VWDJSVGRWPKW` | `ENTER STAGE TWO` -> Link to `stage2.html` |
| **Stage 2** | Reverse Text | `moc.stnatnocdemrawhctac` | `catchwarmetcontents.com` -> Link to `stage3.html` |
| **Stage 3** | Binary Code | `01110011 01110100 01100001 01100111 01100101 00110100` | `stage4` -> Link to `stage4.html` |
| **Stage 4** | Hexadecimal | `737461676535` | `stage5` -> Link to `stage5.html` |
| **Stage 5** | Atbash Cipher | `GZVTVI GHZGV` | `TEACHER ZACH` -> Link to `stage6.html` |
| **Stage 6** | Vigenere Cipher (Key: `KEY`) | `RIZX MSRV EIBI` | `KEYS OPEN DOOR` -> Link to `stage7.html` |
| **Stage 7** | Sequential (Reverse + Caesar Shift +3) | `WKHQ XVH WKH VKLIW` | `THEN USE THE SHIFT` -> Link to `stage8.html` |
| **Stage 8** | Combined Final Key | `stage8final` | Reveals: `"uk i like u and i want u to like me back so bad :("` |
